import { Component, OnInit } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
} from 'ag-grid-community';
import { DataService } from '../services/data.service';
import { ButtonComponent } from '../button/button.component';

@Component({
  selector: 'app-ag-grid-data-table',
  templateUrl: './ag-grid-data-table.component.html',
  styleUrls: ['./ag-grid-data-table.component.css'],
})
export class AgGridDataTableComponent implements OnInit {
  [x: string]: any;
  colDefs!: any[];
  rowData!: any[];
  defaultColDef: any;
  gridOptions: any;
  private gridApi!: GridApi;
  constructor(private dataService: DataService) {
    this.colDefs = [
      {
        headerName: 'Id',
        field: 'id',
        sortable: false,
        filter: false,
        valueGetter: 'node.rowIndex+1',
        width: 60,
      },
      { headerName: 'Name', field: 'name' },
      { headerName: 'User Name', field: 'username' },
      { headerName: 'Email', field: 'email' },
      {
        headerName: 'Address',
        field: 'address',
        valueFormatter: (params: any) => {
          if (params.value) {
            const address = params.value;
            return `${address.street}, ${address.suite}, ${address.city}, ${address.zipcode}`;
          }
          return '';
        },
      },
      {
        headerName: 'Phone',
        field: 'phone',
      },
      {
        headerName: 'Website',
        field: 'website',
      },
      {
        headerName: 'Actions',
        floatingFilter: false,
        cellRenderer: ButtonComponent,
        cellRendererParams: {
          delete: this.onDelete.bind(this),
        },
      },
    ];
    this.defaultColDef = {
      filter: true,
      sortable: true,
      editable: true,
      floatingFilter: true,
      floatingFilterComponentParams: { suppressFilterButton: true },
    };
    this.gridOptions = {
      // Set paginationPageSize and paginationPageSizeSelector
      paginationPageSize: 10, // Your desired page size
      paginationPageSizeSelector: [5, 10, 20, 50], // Available page size options
    };
  }
  onSort(e: any) {
    //console.log(e);
    e.api.refreshCells();
  }

  ngOnInit() {
    this.loadData();
  }
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    //this.loadData();
  }
  loadData() {
    this.dataService.userDetailsdata().subscribe(
      (res: any) => {
        this.rowData = res;
        console.log(this.rowData);
      },
      (error) => {
        console.log('Error in Fetching Data', error);
      }
    );
  }

  onDelete(id: any): void {
    this.dataService.deleteUser(id).subscribe(
      (res) => {
        console.log('Deleted successfully', res);
        // Remove the deleted item from rowData
        this.rowData = this.rowData.filter((item) => item.id !== id);
        // Refresh the grid data
        this.gridApi.setRowData(this.rowData);
        // Refresh all cells in the grid
        this.gridApi.refreshCells();
      },
      (error) => {
        console.error('Delete failed', error);
      }
    );
  }
}
