import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css']
})
export class SideMenuComponent {
  constructor(private router:Router){

  }
  navigateToRoute(type:string){
  this.router.navigate([type])
}
 
//   navigateToRoute(type:any){
//     if(type==='addUser'){
//     this.router.navigate(['/add-user']);
//   }
//     else if(type==='addRole'){
//       this.router.navigate(['/add-role']);
//     }
//     else if(type==='viewUser'){
//       this.router.navigate(['/view-user']);
//     }
//     else(type==='viewRole')
//       this.router.navigate(['/view-role']);
// }


}

 