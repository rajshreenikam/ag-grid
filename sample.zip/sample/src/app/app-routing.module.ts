import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUserComponent } from './add-user/add-user.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewRoleComponent } from './view-role/view-role.component';
import { AgGridDataTableComponent } from './ag-grid-data-table/ag-grid-data-table.component';

const routes: Routes = [
  // {path:'',component:AddUserComponent},
  {path:'add-user',component:AddUserComponent},
  {path:'add-role',component:AddRoleComponent},
  {path:'view-user',component:ViewUserComponent},
  {path:'view-role',component:ViewRoleComponent},
  {path:'agGrid-dataTable',component:AgGridDataTableComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

 
export class AppRoutingModule { }
