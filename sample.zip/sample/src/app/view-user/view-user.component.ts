import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserserviceService } from '../services/userservice.service';
import * as XLSX from 'xlsx'; 
import { GridApi, GridReadyEvent,   } from 'ag-grid-community';
import { DataService } from '../services/data.service';
import { ButtonComponent } from '../button/button.component';
 
@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css'],
})
export class ViewUserComponent {
  username!:string;
  name!: string;
  surName!: string;
  rowData: any[] = [];
  columnDefs!: any[];
  defaultColDef: any;
  gridOptions: any;
  private gridApi!: GridApi;

  constructor(
    private route: ActivatedRoute,
    private userService: UserserviceService,
    private dataService: DataService
  ) {
    this.userService.userName.subscribe((name: string) => {
      this.name = name;
    });
    this.columnDefs = [
      {
        headerName: 'Sr.No',
        valueGetter: 'node.rowIndex + 1',
        sortable: false,
        filter:false,
        width:70,
        
      },
      { headerName: 'Mission',
       field: 'mission', 
       checkboxSelection: true,
       headerCheckboxSelection:true ,
       width:200
      },
      { headerName: 'Company', field: 'company' ,width:120},
      { headerName: 'Location', field: 'location'},
      { headerName: 'Date', field: 'date',width:170},
      { headerName: 'Time', field: 'time' ,width:100},
      { headerName: 'Rocket', field: 'rocket',width:180 },
      { headerName: 'Price', field: 'price',width:100}, 
      {
        headerName: 'Actions',
        field: 'action',
        cellRenderer: ButtonComponent,
        floatingFilter: false,
      },
      // { headerName: 'Successful', field: 'successful' },
       
    ];

    this.defaultColDef = {
      //flex: 1,
      // minWidth: 200,
      filter: 'agTextColumnFilter',
      sortable: true,
      editable: true,
      floatingFilter: true,
     // pinned: 'left'
     floatingFilterComponentParams: { suppressFilterButton: true }
     
    };
    

    this.gridOptions = {
      rowSelection: 'multiple',
      // onRowClicked: this.onRowClicked.bind(this),
      onRowSelected: this.onRowSelected.bind(this),
    };
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.loadData();
  }

  onSort(e: any) {
    console.log(e);
    e.api.refreshCells();
  }
  
  ngOnInit() {
    // Read the user name from the query parameter
    //this.name = this.route.snapshot.queryParams['name'];
    //this.rowData=this.dataService.getData()
    //this.loadData();
  }

  // onRowClicked(event: CellClickedEvent): void {
  //   console.log('Row clicked:', event.data);
  //   // event.data contains the data of the clicked row
  // }

  onRowSelected(event: any): void {
    if (event.node.selected) {
      console.log('Row selected:', event.data);
      // event.data contains the data of the selected row
    }
  }

  // onSubmit(){
  //   const fullName=`${this.name} ${this.surName}`;
  //   console.log(fullName);
  //   localStorage.setItem('fullName',fullName)
  // }

  submitUser() {
    this.userService.setUserSurname(this.surName);
    const fullName = `${this.name} ${this.surName}`;
    localStorage.setItem('fullname', fullName);
  }
  loadData() {
    this.dataService.spaceMissionData().subscribe(
      (response: any) => {
        this.rowData = response;
        console.log('-----', this.rowData);
      },
      (error) => {
        console.error('Error fetching data:', error);
        // Handle the error or set a default value for this.rowData
      }
    );
  }
  


  exportToExcel() {
    if (this.gridApi) {
      const toTitleCase = (str: string) => {
        return str.replace(/\w\S*/g, function (txt) {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      };

      const rowDataTitleCase = this.rowData.map((item) => {
        const newItem: any = {};
        Object.keys(item).forEach((key) => {
          newItem[toTitleCase(key)] = item[key];
        });
        return newItem;
      });

      // Create a new workbook
      const wb = XLSX.utils.book_new();
      // Create a new worksheet
      const ws = XLSX.utils.json_to_sheet(rowDataTitleCase);

      // Adjust column widths dynamically based on content
      const columnWidths = this.calculateColumnWidths(rowDataTitleCase);
      ws['!cols'] = columnWidths;

      // Add the worksheet to the workbook
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      // Save the workbook as an Excel file
      XLSX.writeFile(wb, 'exportedData.xlsx');
    }
  }

  calculateColumnWidths(data: any[]): { wch: number }[] {
    const columnWidths: { wch: number }[] = [];
    // Iterate through each column
    Object.keys(data[0]).forEach((key) => {
      // Initialize the maximum width for each column
      let maxContentLength = key.length;

      // Iterate through each row to find the maximum content length
      data.forEach((row) => {
        const content = row[key] ? row[key].toString() : '';
        maxContentLength = Math.max(maxContentLength, content.length);
      });

      // Add some padding to the maximum content length
      columnWidths.push({ wch: maxContentLength  });
    });

    return columnWidths;
  }

  exportToCSV() {
      this.gridApi.exportDataAsCsv();
    }
}
