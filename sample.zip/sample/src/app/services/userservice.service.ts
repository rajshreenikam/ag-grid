import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  private userNameSource= new BehaviorSubject<string>('');
  userName=this.userNameSource.asObservable();

  private userSurnameSource=new BehaviorSubject<string>('');
  userSurname=this.userSurnameSource.asObservable();


  constructor() { }

  setUserName(name:string){
    this.userNameSource.next(name);
  }

setUserSurname(surname:string){
  this.userSurnameSource.next(surname);
}
}
