import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private apiUrl = 'https://www.ag-grid.com/example-assets/space-mission-data.json';
  private userDetailsApi="http://localhost:3000/users";
  constructor(private http:HttpClient) { }

  // getData() {
  //   return [
  //     { make: 'Toyota', model: 'Celica', price: 35000 },
  //     { make: 'Ford', model: 'Mondeo', price: 32000 },
  //     { make: 'Porsche', model: 'Boxster', price: 72000 },
  //   ];
  // }
 spaceMissionData(){
  return this.http.get(this.apiUrl);
 }
 userDetailsdata(){
  return this.http.get(this.userDetailsApi);
 }
 
 editUserDetails(userDetails: any): Observable<any> {
  return this.http.put(`${this.userDetailsApi}/${userDetails.id}`, userDetails);
}

deleteUser(userId: string): Observable<any> {
  return this.http.delete(`${this.userDetailsApi}/${userId}`);
}
  
}
