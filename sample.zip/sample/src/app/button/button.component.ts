import { Component, Input } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {
  public params: any;
  @Input() delete: Function | undefined;


  constructor(private dataService:DataService){

  }

  agInit(params: any): void {
    this.params = params;
  }

  // refresh(params: any): boolean {
  //   return true;
  // }

  onEdit(id:any): void {
  //  alert(`Button clicked for row: ${this.params.node.rowIndex + 1}`);
  this.dataService.editUserDetails(id).subscribe((res)=>{
    console.log(res);
  })

  }
  onDelete(id:any):void{  
  const userId = this.params.data.id;
    this.dataService.deleteUser(userId).subscribe((res)=>{
      console.log('_____',res);
    },
    error=>{
        console.error('Delete failed', error);
    }
    )

  }
  handleDelete(id: any): void {
    if (this.onDelete) {
      this.onDelete(id);
    }
  }
 
}
