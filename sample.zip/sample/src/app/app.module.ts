import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewRoleComponent } from './view-role/view-role.component';
import { FormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
 
import { HttpClientModule } from  '@angular/common/http';
import { ButtonComponent } from './button/button.component';
import { AgGridDataTableComponent } from './ag-grid-data-table/ag-grid-data-table.component';
 
 
 


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SideMenuComponent,
    AddUserComponent,
    AddRoleComponent,
    ViewUserComponent,
    ViewRoleComponent,
    ButtonComponent,
    AgGridDataTableComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AgGridModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
