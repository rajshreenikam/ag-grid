import { Component, ElementRef, EventEmitter, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../services/userservice.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {

   name: string = '';

  constructor(private router: Router, private userService:UserserviceService) {}

  // onSubmit() {
  //   // Navigate to the ViewUserComponent and pass the user name in the query parameter
  //   this.router.navigate(['/view-user'], { queryParams: { name: this.name } });
  // }

  addUser(){
    this.userService.setUserName(this.name);
    this.router.navigate(['/view-user']);
  }
}
